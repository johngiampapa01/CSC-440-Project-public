<?php
require_once 'dbh.inc.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = $_POST["username"];
    $password = $_POST["password"];
    $email = $_POST["email"];  

    require_once 'createaccount_helperfunctions.inc.php';
    require_once 'createaccount_errors.inc.php';

    //error handling
    //array to hold errors
    $errorsArray = [];

    if (input_empty_check($username, $password, $email)){
        $errorsArray ["input_is_empty"] = "Fill in all fields.";
    }
    if (email_invalid_check($email)){
        $errorsArray ["email_is_invalid"] = "Invalid email address used.";
    }
    if (username_taken_check($conn, $username)){
        $errorsArray ["username_is_taken"] = "Username is already in use by another user.";
    }
    if (email_taken_check($conn, $email)){
        $errorsArray ["email_is_taken"] = "Email is already in use by another user.";
    }

    if(empty($errorsArray)){
        //creating account if no errors thrown
        $insertQuery = "INSERT INTO useraccounts (username, password, email) VALUES (?, ?, ?)";
        $insertStmt = $conn->prepare($insertQuery);

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $insertStmt->bind_param("sss", $username, $hashedPassword, $email);

        $insertStmt->execute();

        header("Location: ../createaccount/success.html");

        $conn->close();
        $insertStmt->close();

        die();
    } else {
        require_once 'session_config.inc.php';
        $_SESSION["errors_in_createaccount"] = $errorsArray;
        header("Location: ../createaccount/createaccounthtml.php");
        die();
    }
} else {
    header("Location: ../index.html");
    die();
}
?>