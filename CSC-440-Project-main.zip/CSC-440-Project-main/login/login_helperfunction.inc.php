<?php

declare(strict_types=1);

function get_username(object $conn, string $username){
    // Check if the username is already taken
    $checkUsernameQuery = "SELECT * FROM useraccounts WHERE username = ?";
    $checkUsernameStmt = $conn->prepare($checkUsernameQuery);
    $checkUsernameStmt->bind_param("s", $username);
    $checkUsernameStmt->execute();
    $result = $checkUsernameStmt->get_result();

    $resultMysqli = mysqli_fetch_all($result, MYSQLI_ASSOC);

    return $resultMysqli;
}

function get_password(object $conn, string $username) {
    // Check if the username exists
    $checkUsernameQuery = "SELECT * FROM useraccounts WHERE username = ?";
    $checkUsernameStmt = $conn->prepare($checkUsernameQuery);
    $checkUsernameStmt->bind_param("s", $username);
    $checkUsernameStmt->execute();
    $result = $checkUsernameStmt->get_result();

    $userArray = mysqli_fetch_assoc($result);

    $password = isset($userArray['password']) ? $userArray['password'] : null;

    return $password;
}

