<?php
    require_once 'login_viewerrors.inc.php';
    require_once 'session_config.inc.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Tech Forum</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <header>
        <h1>Tech Talk Hub User Login</h1>

    <div id="logo"> 
        <img src="../pictures/logo.png"> 
    </div> 
    </header>
    <main>
        <section id="login-form">
            <h2>Login</h2>
            <form action="login.inc.php" method="post">
                <input type="text" name="username" placeholder="Username">
                <input type="password" name="password" placeholder="Password">
                <button id="user_username" type="submit" class="submit">Submit</button>
                
                <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Check if the form has been submitted
                        if (isset($_POST['username'])) {
                            $userText = $_POST['username'];
                            echo "Value received from the form: " . htmlspecialchars($userText);
        
                            // Set the cookie
                            setcookie('username_cookie', $userText, time() + (86400 * 30), '/');
                            setcookie('loggedinuserid_cookie', $userText, time() + (86400 * 30), '/');
                        } else {
                        echo "No input received.";
                        }
                    }
                ?>



            </form>

            
            
                <a href="../createaccount/createaccounthtml.php"> <button class="createaccount"> CreateAccount</button></a>

            <?php
            login_errors_check();


            ?>



            
        </section>
    </main>
</body>
</html>
