<?php

function getAllUsers($conn) {
$sql = "SELECT * FROM useraccounts WHERE username <> 'admin'";
$getallusers = $conn->query($sql);

return $getallusers;
}

?>
