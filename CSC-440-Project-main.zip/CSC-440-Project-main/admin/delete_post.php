<?php
include_once('dbh.inc.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['post_id'])) {
    // Get the post ID from the form
    $postID = $_POST['post_id'];

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL query to delete the forum post
    $sql = "DELETE FROM forumpost WHERE postid = ?";

    // Execute query with prepared statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $postID);
    $stmt->execute();

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Redirect back to the forum or another appropriate page
    header("Location: ../forum&comments/indexhtml.php");
    exit();
} else {
    // If the form is not submitted, redirect to the forum or another appropriate page
    header("Location: ../forum&comments/indexhtml.php");
    exit();
}
?> 