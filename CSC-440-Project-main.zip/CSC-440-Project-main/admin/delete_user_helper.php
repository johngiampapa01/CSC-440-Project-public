<?php
function delete_user(object $conn, int $userId) {

    $sql = "DELETE FROM useraccounts WHERE userid = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        return "Error in SQL preparation: " . $conn->error;
    }

    $stmt->bind_param("i", $userId);

    if ($stmt->execute()) {
        return "User deleted successfully.";
    } else {
        return "Error deleting user: " . $stmt->error;
    }
}
?>