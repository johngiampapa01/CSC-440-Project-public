<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">
    <title>Admin Panel</title>
</head>
<body>
    <header>
        <h1>Tech Talk Hub User Management</h1>

            <form action="logout.inc.php" method="post">
                <button action="logout.inc.php" type="logout" class="logout">Logout </button>
            </form> 

                
            <a href="../forum&comments/indexhtml.php"> <button class="forum"> Forum</button></a>

            

    <div id="logo"> 
        <img src="../pictures/logo.png"> 
    </div> 
    </header>
    
    <main>
        <section id = "managment-form">
        <?php
        require_once 'dbh.inc.php';
        require_once 'get_users_helper.php'; 
        require_once 'delete_user_helper.php'; 

        // Check if a user deletion request is submitted
        if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['userId'])) {
            $deletedUserId = $_GET['userId'];
            delete_user($conn, $deletedUserId);
        }

        $result = getAllUsers($conn);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="user-item">';
                echo 'User ID: ' . $row["userid"] . ' | Username: ' . $row["username"] . ' | ';
                echo '<a href="adminhtml.php?action=delete&userId=' . $row["userid"] . '">Delete</a>';
                echo '</div>';
            }
        } else {
            echo '<p class="no-users">No users found.</p>';
        }
        ?>
        </section>
    </main>
</body>
</html>
