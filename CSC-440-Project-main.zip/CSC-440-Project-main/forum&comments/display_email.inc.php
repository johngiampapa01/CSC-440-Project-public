
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile_page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<?php
session_start();
require_once('dbh.inc.php');


// checking if cookie is transfering properly
if (isset($_COOKIE['username_cookie'])) {
    $usernameee = $_COOKIE['username_cookie'];
    //echo $usernameee; 
} else {
    echo "Cookie not set or unavailable.";
}

$sql = "SELECT email, createdat FROM useraccounts WHERE username = '$usernameee'";




$usernameToFind = $usernameee; 

 // Sanitize input to prevent SQL injection
$usernameToFind = $conn->real_escape_string($usernameToFind); 

$sql = "SELECT userid, email, createdat FROM useraccounts WHERE username = '$usernameToFind'";

$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $userid = $row["userid"];
            $userEmail = $row["email"];
            $createdAt = $row["createdat"];

            echo "<div style='border: 1px solid #ccc; padding: 20px; margin-bottom: 20px; text-align: center; background-color: #97caef;'>";
            echo "<body style='background-color: #97caef;'>";
            echo "<h3>User Information</h3>";
            echo "<p><strong>User ID:</strong> " . $userid . "</p>";
            echo "<p><strong>User Email:</strong> " . $userEmail . "</p>";
            echo "<p><strong>Date Created:</strong> " . $createdAt . "</p>";
            echo "</div>";
        }
    } else {
        echo "No user found with the username '$usernameToFind'.";
    }
} else {
    echo "Error in the SQL query: " . $conn->error;
}

$conn->close();
?>

<a href="indexhtml.php">
    <div class="d-grid gap-2 col-6 mx-auto">
    <button class="btn btn-primary" type="button" action>Back</button>
    </div>
</a>

</body>
</html>





