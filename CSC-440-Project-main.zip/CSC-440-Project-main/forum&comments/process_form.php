<?php
session_start();
require_once 'dbh.inc.php';

// Ensure the form is submitted via POST method
if (isset($_POST['submit-post']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input to prevent XSS attacks
    $title = filter_input(INPUT_POST, 'post-title', FILTER_SANITIZE_STRING);
    $content = filter_input(INPUT_POST, 'post-content', FILTER_SANITIZE_STRING);
    $tag = filter_input(INPUT_POST, 'post-tag', FILTER_SANITIZE_STRING);

    //added by john
    // checking if cookie is transfering properly
    if (isset($_COOKIE['username_cookie'])) {
        $usernameee = $_COOKIE['username_cookie'];
        //echo $usernameee; 
    } else {
     echo "Cookie not set or unavailable.";
    }

    $usernameToFind = $usernameee; 

    // Sanitize input to prevent SQL injection
    $usernameToFind = $conn->real_escape_string($usernameToFind); 

    $sqluseridforforum = "SELECT userid FROM useraccounts WHERE username = '$usernameToFind'";
    $result = $conn->query($sqluseridforforum);
    $row = $result->fetch_assoc();
    $useridforforum = $row["userid"];

    
    $sql = "INSERT INTO forumpost (userid, title, content, tag) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    
    if ($stmt === false) {
        die("Error in SQL preparation: " . $conn->error);
    }

    
    $stmt->bind_param("isss", $useridforforum, $title, $content, $tag);

    
    if ($stmt->execute()) {
        header("Location: ../forum&comments/indexhtml.php");
        echo "Post submitted successfully";
    } else {
        echo "Error in executing SQL: " . $stmt->error;
    }

    
    $stmt->close();
}


if (isset($conn) && $conn) {
    $conn->close();
}
?>
