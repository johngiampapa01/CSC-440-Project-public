<?php
include_once ('dbh.inc.php');

    
    if (isset($_POST['user1Id']) && isset($_POST['user2Id'])) {
        $user1Id = $_POST['user1Id'];
        $user2Id = $_POST['user2Id'];

        //checks if friend request has been sent sucessfully
        $sql = "INSERT INTO friends (friendid, user1id, user2id, status, actionuserid)
                VALUES (NULL, $user1Id, $user2Id, 'pending', $user1Id)";

        if ($conn->query($sql) === TRUE) {
            echo "Friend request sent successfully!";
        } else {
            echo "Error sending friend request!";
        }
    }

    $conn->close();
    exit(); 

?>

<!DOCTYPE html>
<html>
<head>
  <title>Friend Adding System</title>
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    
    .friend-system {
      margin-top: 50px;
    }
  </style>
</head>
<body>
  <div class="container friend-system">
    <h2 class="text-center mb-4">Friend Adding System</h2>
    <div class="row justify-content-center">
      <div class="col-md-4">
        <form>
          <div class="mb-3">
            <label for="user1Id" class="form-label">Your ID</label>
            <input type="text" class="form-control" id="user1Id" placeholder="Your ID">
          </div>
          <div class="mb-3">
            <label for="user2Id" class="form-label">Friend's ID</label>
            <input type="text" class="form-control" id="user2Id" placeholder="Friend's ID">
          </div>
          <button type="button" class="btn btn-primary" onclick="sendFriendRequest()">Send Friend Request</button>
        </form>
      </div>
    </div>
  </div>

  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  
  <script>
    function sendFriendRequest() {
      const user1Id = document.getElementById('user1Id').value;
      const user2Id = document.getElementById('user2Id').value;

      // AJAX request to send friend request so it wokrs with out refresing the page
      const xhr = new XMLHttpRequest();
      const url = 'friends.inc.php'; 
      const params = `user1Id=${user1Id}&user2Id=${user2Id}`;

      xhr.open('POST', url, true);
      xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

      // checks if response is ok or if its done
      xhr.onreadystatechange = function () {
        if (xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
          


          const response = xhr.responseText;
          alert(response); 
        }
      };

      xhr.send(params);
    }
  </script>
</body>
</html>
