<?php

include_once('dbh.inc.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // make sure simething was submitted
    if (isset($_POST['comment']) && isset($_POST['post_id'])) {
        // get the comment and post ID from the form data
        $comment = $_POST['comment'];
        $postID = $_POST['post_id'];
        
        // Get the username from the cookie
        // this has been wokring joe
        if (isset($_COOKIE['username_cookie'])) {
            $username = $_COOKIE['username_cookie'];

            // Prepare a query to fetch the user ID based on the username
            $query = "SELECT userid FROM useraccounts WHERE username = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $result = $stmt->get_result();

            
            if ($result->num_rows > 0) {
                
                $row = $result->fetch_assoc();
                $userID = $row['userid'];

                
                $sql = "INSERT INTO forumcomments (postid, userid, colmment) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('iis', $postID, $userID, $comment);

                
                if ($stmt->execute()) {
                    // back to main page
                    header("Location: indexhtml.php"); 
                    exit();
                } else {
                    
                    echo "Error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                echo "User not found.";
            }
        } else {
            echo "Username cookie not set or unavailable.";
        }
    } else {
        echo "Please fill in all required fields.";
    }
} else {
    echo "Invalid request method.";
}

$conn->close();
?>
