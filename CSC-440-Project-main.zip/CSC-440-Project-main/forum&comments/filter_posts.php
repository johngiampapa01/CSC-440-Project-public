<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
    
</body>
</html>
<?php
include_once('dbh.inc.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['selectedTag'])) {
    $selectedTag = $_POST['selectedTag'];

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL query to fetch posts based on the selected tag
    if ($selectedTag == 'All') {
        $sql = "SELECT forumpost.*, useraccounts.userid, useraccounts.username FROM forumpost JOIN useraccounts ON forumpost.userid = useraccounts.userid";
    } else {
        $sql = "SELECT forumpost.*, useraccounts.userid, useraccounts.username FROM forumpost JOIN useraccounts ON forumpost.userid = useraccounts.userid WHERE tag = ?";
    }

    
    //added by john
    // checking if cookie is transfering properly
        if (isset($_COOKIE['username_cookie'])) {
            $usernameee = $_COOKIE['username_cookie'];
            //echo $usernameee; 
        } else {
            echo "Cookie not set or unavailable.";
        }
    
    // Execute query with prepared statement
    $stmt = $conn->prepare($sql);
    if ($selectedTag != 'All') {
        $stmt->bind_param('s', $selectedTag);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
?>
            
            <div class="container mt-4 border rounded p-3 position-relative">
                <div class="col-md-12">
                    <h4 style="font-weight: bold;"><?php echo $row['title']; ?></h4>
                    <?php
                    if ($usernameee === 'admin'){
                            echo '<form action="../admin/delete_post.php" method="post" class="position-absolute top-0 end-0 mt-2">';
                            echo '<input type="hidden" name="post_id" value="' . $row['postid'] . '">';
                            echo '<button type="submit" class="delete">Delete Post</button>';
                            echo '</form>';
                        }
                    ?>
                    <div class="content-info">
                        <p><?php echo $row['content']; ?></p>
                        <p>
                            <span>User: 
                                <a href="#" class="user-link" data-bs-toggle="modal" data-bs-target="#userModal<?php echo $row['userid']; ?>">
                                    <?php echo $row['username']; ?>
                                </a>
                            </span>
                            <span style="margin-left: 10px;">Post ID: <?php echo $row['postid']; ?></span>
                        </p>
                    </div>
                </div>

                        
                        <?php



                        // Display existing comments for the current post
                        $postID = $row['postid'];
                        $commentSql = "SELECT fc.*, ua.username 
                        FROM forumcomments fc 
                        JOIN useraccounts ua ON fc.userid = ua.userid 
                        WHERE fc.postid = ?";
                        $commentStmt = $conn->prepare($commentSql);
                        $commentStmt->bind_param('i', $postID);
                        $commentStmt->execute();
                        $commentResult = $commentStmt->get_result();

                        if ($commentResult->num_rows > 0) {
                            while ($commentRow = $commentResult->fetch_assoc()) {
                                

                                echo '<div class="container mt-2 border rounded p-2">';
                                //echo '<p>' . $commentRow['colmment'] . '</p>';
                                echo '<p><strong>' . $commentRow['username'] . ':</strong> ' . $commentRow['colmment'] . '</p>';
                                echo '</div>';
                            }
                        } else {
                            echo '<p><span style="font-size:0.8em">Be the first to comment!</span></p>';
                        }
                        $commentStmt->close();
                        
                        if (isset($_COOKIE['username_cookie'])) {
                            $usernameee = $_COOKIE['username_cookie'];
                            //echo $usernameee; 
                        } else {
                            echo "Cookie not set or unavailable.";
                        }
                        

                        $sql33 = "SELECT userid FROM useraccounts WHERE username = '$usernameee'";
                        




                        ?>
                        <!-- Comment box for each post -- each post shoudl be seperate!!!!! -->
                        <form action="submit_comment.php" method="post">
                            <div class="form-group">
                                
                                <textarea class="form-control" rows="3" name="comment" placeholder="Comment here"></textarea>
                                <!-- Hidden input to pass post ID or other identifiers -->
                                <input type="hidden" name="post_id" value="<?php echo $row['postid']; ?>">
                                <input type="hidden" name="user_id" value="<?php echo $row['userid']; ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit Comment</button>
                        </form>
                    </div>
                </div>
            </div>

        
<?php
        }
    } else {
        echo "No results found";
    }

   
    $stmt->close();
    $conn->close();
}
?>







